<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;

class BookingController extends Controller
{
     /**
     * Menampilkan daftar semua pemesanan.
     */
    public function index()
    {
        // Ambil semua data booking, beserta data relasi user dan car
        // untuk menghindari query N+1. Urutkan dari yang terbaru.
        $bookings = Booking::with(['user', 'car'])->latest()->paginate(10);

        return view('admin.bookings.index', compact('bookings'));
    }

    /**
     * Menampilkan detail dari satu pemesanan.
     */
    public function show(string $id)
    {
        // === PERBAIKAN DI SINI ===
        // Cari data booking secara manual berdasarkan ID.
        // Eager load relasi 'user' dan 'car' untuk efisiensi.
        // findOrFail akan otomatis menampilkan 404 jika ID tidak ditemukan.
        $booking = Booking::with(['user', 'car'])->findOrFail($id);

        // Kirim data booking yang sudah ditemukan ke view.
        return view('admin.bookings.show', compact('booking'));
    }

     /**
     * Memperbarui status dari sebuah pemesanan.
     */
     public function updateStatus(Request $request, Booking $booking)
    {
        // Validasi input dari form
        $validated = $request->validate([
            'status' => 'required|in:pending,confirmed,cancelled,completed',
        ]);

        // 1. UPDATE status pesanan menjadi 'completed' (atau status lain yang dipilih)
        $booking->status = $validated['status'];
        $booking->save();

        // 2. LOGIKA TAMBAHAN: Jika status adalah 'completed', maka mobil kembali tersedia.
        // Ini sesuai dengan langkah "UPDATE status mobil menjadi 'available'" pada diagram.
        if ($booking->status == 'completed' || $booking->status == 'cancelled') {
            // Pastikan relasi 'car' ada untuk menghindari error
            if ($booking->car) {
                $booking->car->status = 'available';
                $booking->car->save();
            }
        }

        // 3. Redirect kembali ke halaman detail dengan notifikasi sukses
        return redirect()->route('admin.bookings.show', $booking->id)->with('success', 'Status pesanan berhasil diperbarui!');
    }
}
