<footer class="app-footer">
    <div class="float-end d-none d-sm-inline">Cakrawala Trans Group</div>
    <strong>
        {{-- Membuat tahun menjadi dinamis --}}
        Copyright &copy; 2024-{{ date('Y') }}&nbsp;
        <a href="{{ route('home') }}" class="text-decoration-none">Cakrawala Trans</a>.
    </strong>
    All rights reserved.
    </footer>
