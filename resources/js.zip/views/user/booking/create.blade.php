@extends('layouts.user')

{{-- 1. Memberitahu Blade untuk menggunakan layout utama 'layouts/user.blade.php' --}}
@include('components.user.navbar')
@section('content')
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('{{ asset('/images/bg_2.jpg') }}');"
        data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
                <div class="col-md-9 ftco-animate pb-5">
                    <p class="breadcrumbs">
                        <span class="mr-2"><a href="{{ route('home') }}">Home <i
                                    class="ion-ios-arrow-forward"></i></a></span>
                        <span class="mr-2"><a href="{{ route('cars.show', $car->id) }}">Detail Mobil <i
                                    class="ion-ios-arrow-forward"></i></a></span>
                        <span>Pemesanan <i class="ion-ios-arrow-forward"></i></span>
                    </p>
                    <h1 class="mb-3 bread">Formulir Pemesanan</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <h3 class="mb-4">Detail Mobil Pilihan Anda</h3>
                    <div class="car-details">
                        <div class="img rounded"
                            style="background-image: url('{{ $car->image ? asset('storage/' . $car->image) : asset('user_template/images/bg_1.jpg') }}'); background-size: cover; height: 300px;">
                        </div>
                        <div class="text text-center mt-4">
                            <span class="subheading">Tahun: {{ $car->year }}</span>
                            <h2>{{ $car->brand }} {{ $car->model }}</h2>
                            <h4>Rp {{ number_format($car->rental_price, 0, ',', '.') }} / hari</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">

                    <h3 class="mb-4">Pilih Tanggal Sewa</h3>
                    <form action="{{ route('booking.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        {{-- Simpan ID mobil secara tersembunyi --}}
                        <input type="hidden" name="car_id" value="{{ $car->id }}">

                        <div class="form-group">
                            <label for="start_date">Tanggal Mulai Sewa</label>
                            <input type="date" name="start_date"
                                class="form-control @error('start_date') is-invalid @enderror"
                                value="{{ old('start_date') }}" required>
                            @error('start_date')
                                <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="end_date">Tanggal Selesai Sewa</label>
                            <input type="date" name="end_date"
                                class="form-control @error('end_date') is-invalid @enderror" value="{{ old('end_date') }}"
                                required>
                            @error('end_date')
                                <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                         <div class="form-group mt-4">
                        <label for="name"><strong>Nama Lengkap (sesuai KTP)</strong></label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" id="name"
                            name="name" placeholder="Masukkan nama lengkap Anda" required
                            value="{{ old('name', auth()->user()->name) }}">
                        @error('name')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="form-group mt-4">
                        <label for="nik"><strong>Nomor Induk Kependudukan (NIK)</strong></label>
                        <input type="text" class="form-control @error('nik') is-invalid @enderror" id="nik"
                            name="nik" placeholder="Masukkan 16 digit NIK Anda" required value="{{ old('nik') }}">
                        @error('nik')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                        <div class="form-group mt-4">
                            <label for="ktp_image"><strong>Upload Foto KTP Atau Identitas lain</strong></label>
                            <p class="text-muted">Untuk keperluan verifikasi, harap unggah foto KTP / Identitas Asli Anda
                                yang jelas. (Format: JPG, PNG, Maks: 2MB)</p>
                            <input type="file" class="form-control-file @error('ktp_image') is-invalid @enderror"
                                id="ktp_image" name="ktp_image" required>
                            @error('ktp_image')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary py-3 px-4">Lanjutkan Pemesanan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection
