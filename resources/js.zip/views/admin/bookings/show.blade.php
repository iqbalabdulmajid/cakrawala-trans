@extends('layouts.admin')

@section('title', 'Detail Pesanan #' . $booking->id)

@section('contents')
    {{-- Menampilkan pesan sukses setelah admin mengupdate status --}}
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="row">
        {{-- KARTU DETAIL PESANAN UTAMA --}}
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detail Pesanan #{{ $booking->id }}</h3>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th style="width: 200px;">ID Pesanan</th>
                                <td>#{{ $booking->id }}</td>
                            </tr>
                            <tr>
                                <th>Status Pesanan</th>
                                <td>
                                    @php
                                        // Logika untuk menentukan warna badge berdasarkan status
                                        $statusClass = 'badge ';
                                        if ($booking->status == 'pending') {
                                            $statusClass .= 'bg-warning';
                                        } elseif ($booking->status == 'confirmed') {
                                            $statusClass .= 'bg-success';
                                        } elseif ($booking->status == 'completed') {
                                            $statusClass .= 'bg-primary';
                                        } elseif ($booking->status == 'cancelled') {
                                            $statusClass .= 'bg-danger';
                                        }
                                    @endphp
                                    <span class="{{ $statusClass }}">{{ ucfirst($booking->status) }}</span>
                                </td>
                            </tr>
                            <tr>
                                <th>Tanggal Mulai</th>
                                <td>{{ $booking->start_date ? \Carbon\Carbon::parse($booking->start_date)->format('l, d F Y') : 'N/A' }}
                                </td>
                            </tr>
                            <tr>
                                <th>Tanggal Selesai</th>
                                <td>{{ $booking->end_date ? \Carbon\Carbon::parse($booking->end_date)->format('l, d F Y') : 'N/A' }}
                                </td>
                            </tr>
                            <tr>
                                <th>Total Harga</th>
                                <td><strong>Rp
                                        {{ number_format($booking->total_price, 0, ',', '.') }}</strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {{-- FORM UNTUK UPDATE STATUS DAN CEK KONDISI --}}
                <div class="card-footer">
                    <form action="{{ route('admin.bookings.updateStatus', $booking->id) }}" method="POST">
                        @csrf
                        @method('PUT') {{-- Method untuk update adalah PUT --}}

                        {{-- BAGIAN BARU: FORM CEK FISIK KENDARAAN --}}
                        <div class="card card-info card-outline mb-4">
                            <div class="card-header">
                                <h5 class="card-title">Checklist Kondisi Kendaraan</h5>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="cek_body" id="cek_body"
                                            required>
                                        <label class="form-check-label" for="cek_body">Kondisi Body & Cat (Tidak ada lecet
                                            baru)</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="cek_interior"
                                            id="cek_interior" required>
                                        <label class="form-check-label" for="cek_interior">Kebersihan Interior & Tidak Bau
                                            Rokok</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="cek_ban" id="cek_ban"
                                            required>
                                        <label class="form-check-label" for="cek_ban">Kondisi Ban & Velg</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="cek_dokumen" id="cek_dokumen"
                                            required>
                                        <label class="form-check-label" for="cek_dokumen">Kelengkapan Dokumen (STNK)</label>
                                    </div>
                                </div>
                                <div class="form-group mt-3">
                                    <label for="return_notes">Catatan Tambahan (jika ada kerusakan atau denda)</label>
                                    <textarea name="return_notes" id="return_notes" class="form-control" rows="3"
                                        placeholder="Contoh: Ada lecet di bumper belakang, denda Rp 150.000"></textarea>
                                </div>
                            </div>
                        </div>
                        {{-- AKHIR BAGIAN BARU --}}

                        <div class="row align-items-end">
                            <div class="col-md-8">
                                <label for="status">Ubah Status Pesanan:</label>
                                <select name="status" class="form-control">
                                    <option value="pending" {{ $booking->status == 'pending' ? 'selected' : '' }}>Pending
                                    </option>
                                    <option value="confirmed" {{ $booking->status == 'confirmed' ? 'selected' : '' }}>
                                        Confirmed</option>
                                    <option value="completed" {{ $booking->status == 'completed' ? 'selected' : '' }}>
                                        Completed</option>
                                    <option value="cancelled" {{ $booking->status == 'cancelled' ? 'selected' : '' }}>
                                        Cancelled</option>
                                </select>
                            </div>
                            <div class="card-body">
                                @if ($booking->ktp_image)
                                    <p><strong>Foto KTP Pelanggan:</strong></p>
                                    <a href="{{ asset('storage/' . $booking->ktp_image) }}" target="_blank">
                                        <img src="{{ asset('storage/' . $booking->ktp_image) }}" alt="Foto KTP"
                                            class="img-fluid rounded" style="max-height: 200px;">
                                    </a>
                                    <a href="{{ asset('storage/' . $booking->ktp_image) }}" target="_blank"
                                        class="btn btn-info btn-sm d-block mt-2">Lihat Ukuran Penuh</a>
                                @else
                                    <p class="text-muted">Pelanggan belum mengunggah foto KTP.</p>
                                @endif
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary w-100">Update & Selesaikan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        {{-- KARTU DETAIL PELANGGAN & MOBIL --}}
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detail Pelanggan</h3>
                </div>
                <div class="card-body p-0">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Nama</th>
                                <td>{{ optional($booking->user)->name }}</td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td>{{ optional($booking->user)->email }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-header">
                    <h3 class="card-title">Detail Mobil</h3>
                </div>
                <div class="card-body p-0">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Merek</th>
                                <td>{{ optional($booking->car)->brand }}</td>
                            </tr>
                            <tr>
                                <th>Model</th>
                                <td>{{ optional($booking->car)->model }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-3">
        <a href="{{ route('admin.bookings.index') }}" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Kembali ke Daftar Pesanan
        </a>
    </div>
@endsection
